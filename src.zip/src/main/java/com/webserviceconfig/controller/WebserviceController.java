package com.webserviceconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.webserviceconfig.exception.WebserviceException;
import com.webserviceconfig.model.Webservice;
import com.webserviceconfig.model.JSON.WebserviceResInfo;
import com.webserviceconfig.service.WebAppService;

@RestController
@RequestMapping(value = "/ws")
public class WebserviceController {
	
	@Autowired
	private WebAppService webAppServiceImpl;

	final static Logger logger = LoggerFactory.getLogger(WebserviceController.class);

	/**
	 * this method is to list all the Web service Application URl's
	 * @return
	 * @throws WebserviceException
	 */
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getAllApplicationServerUrl", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<List<WebserviceResInfo>> listAllWebserviceAppUrls()
			throws WebserviceException {
		logger.info("listAllWebserviceAppUrls method starts");
		List<Webservice> webserviceList = webAppServiceImpl.getAllApplicationServices();
		List<WebserviceResInfo> WebserviceResInfoList = new ArrayList<WebserviceResInfo>();
		
		if(webserviceList != null && webserviceList.size() > 0){
			for (int i = 0; i < webserviceList.size(); i++) {
				WebserviceResInfo webserviceResInfo = new WebserviceResInfo();
				webserviceResInfo.setWebserviceAppId(webserviceList.get(i).getWebserviceId());
				webserviceResInfo.setWebserviceAppName(webserviceList.get(i).getApplicationName());
				webserviceResInfo.setWebserviceAppHost(webserviceList.get(i).getApplicationHost());
				webserviceResInfo.setWebserviceAppPort(webserviceList.get(i).getApplicationPort());
				WebserviceResInfoList.add(webserviceResInfo);
			}
		}
 		return new ResponseEntity<List<WebserviceResInfo>>(WebserviceResInfoList, HttpStatus.OK);
	}
	
	/**
	 * this method is to list all the Web service Application URl's
	 * @return
	 * @throws WebserviceException
	 */
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getAppHostByAppName", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<WebserviceResInfo> getWebServiceAppHostByAppName(@RequestParam(value = "webserviceAppName") String webserviceAppName)
			throws WebserviceException {
		logger.info("getWebServiceAppHostByAppName method starts");
		Webservice webservice = webAppServiceImpl.getApplicationHostByAppName(webserviceAppName);
		WebserviceResInfo webserviceResInfo = new WebserviceResInfo();
		
		if(webservice != null){			
 				webserviceResInfo.setWebserviceAppId(webservice.getWebserviceId());
				webserviceResInfo.setWebserviceAppName(webservice.getApplicationName());
				webserviceResInfo.setWebserviceAppHost(webservice.getApplicationHost());
				webserviceResInfo.setWebserviceAppPort(webservice.getApplicationPort());
  		}
 		return new ResponseEntity<WebserviceResInfo>(webserviceResInfo, HttpStatus.OK);
	}

		
}
