package com.webserviceconfig.service;

import java.util.List;

import com.webserviceconfig.exception.WebserviceException;
import com.webserviceconfig.model.Webservice;

public interface WebAppService {

	public List<Webservice> getAllApplicationServices() throws WebserviceException;
	
	public Webservice getApplicationHostByAppName(String webserviceAppName) throws WebserviceException;

}
