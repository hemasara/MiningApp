package com.webserviceconfig.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webserviceconfig.dao.WebAppServiceDao;
import com.webserviceconfig.exception.WebserviceException;
import com.webserviceconfig.model.Webservice;
import com.webserviceconfig.service.WebAppService;

@Service(value="webAppServiceImpl")
public class WebAppServiceImpl implements WebAppService {
	
	@Autowired
	private WebAppServiceDao webAppServiceDaoImpl;

	@Override
	public List<Webservice> getAllApplicationServices()
			throws WebserviceException {
 		return webAppServiceDaoImpl.getAllApplicationServices();
	}

	@Override
	public Webservice getApplicationHostByAppName(String webserviceAppName)
			throws WebserviceException {
 		return webAppServiceDaoImpl.getApplicationHostByAppName(webserviceAppName);
	}

}
