package com.webserviceconfig.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "webservices")
public class Webservice implements Serializable {

	private static final long serialVersionUID = 5260911419190249826L;
	
	@Id
 	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "WebserviceId")
	private Integer webserviceId;

	@NotEmpty
	@Column(name = "ApplicationName")
	private String applicationName;

	@NotEmpty
	@Column(name = "ApplicationHost")
	private String applicationHost;

	@NotEmpty
	@Column(name = "ApplicationPort")
	private String applicationPort;
	

	public Integer getWebserviceId() {
		return webserviceId;
	}

	public void setWebserviceId(Integer webserviceId) {
		this.webserviceId = webserviceId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getApplicationHost() {
		return applicationHost;
	}

	public void setApplicationHost(String applicationHost) {
		this.applicationHost = applicationHost;
	}

	public String getApplicationPort() {
		return applicationPort;
	}

	public void setApplicationPort(String applicationPort) {
		this.applicationPort = applicationPort;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
}
