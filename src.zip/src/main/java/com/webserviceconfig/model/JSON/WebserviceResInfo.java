package com.webserviceconfig.model.JSON;

import java.io.Serializable;

public class WebserviceResInfo implements Serializable {
 
	private static final long serialVersionUID = -8186727015881476248L;
		 
	private Integer webserviceAppId;
	private String webserviceAppName;
	private String webserviceAppHost;
	private String webserviceAppPort;
	
	public Integer getWebserviceAppId() {
		return webserviceAppId;
	}
	public void setWebserviceAppId(Integer webserviceAppId) {
		this.webserviceAppId = webserviceAppId;
	}
	public String getWebserviceAppName() {
		return webserviceAppName;
	}
	public void setWebserviceAppName(String webserviceAppName) {
		this.webserviceAppName = webserviceAppName;
	}
	public String getWebserviceAppHost() {
		return webserviceAppHost;
	}
	public void setWebserviceAppHost(String webserviceAppHost) {
		this.webserviceAppHost = webserviceAppHost;
	}
	public String getWebserviceAppPort() {
		return webserviceAppPort;
	}
	public void setWebserviceAppPort(String webserviceAppPort) {
		this.webserviceAppPort = webserviceAppPort;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
