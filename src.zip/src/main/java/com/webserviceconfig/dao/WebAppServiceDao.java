package com.webserviceconfig.dao;

import java.util.List;

import com.webserviceconfig.model.Webservice;


public interface WebAppServiceDao {

	public List<Webservice> getAllApplicationServices();

	public Webservice getApplicationHostByAppName(String webserviceAppName);
	 
}
