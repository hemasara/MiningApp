package com.webserviceconfig.dao.Impl;

import java.util.List;

import javax.transaction.Transactional;
import javax.xml.ws.WebServiceException;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.webserviceconfig.dao.AbstractDao;
import com.webserviceconfig.dao.WebAppServiceDao;
import com.webserviceconfig.model.Webservice;
import com.webserviceconfig.service.WebAppService;

@Repository("webAppServiceDaoImpl")
@Transactional
public class WebAppServiceDaoImpl extends AbstractDao<Integer, WebAppService> implements WebAppServiceDao {
	
	final static Logger logger = LoggerFactory.getLogger(WebAppServiceDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory; 

	@Override
	public List<Webservice> getAllApplicationServices() {
		logger.info("getAllApplicationServices method starts");
 		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			String sql = "FROM Webservice";
			Query query = session.createQuery(sql);
			List<Webservice> results = query.list();
			if (null != results && !results.isEmpty()) {
 				return (List<Webservice>) results;
 			}
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			logger.error("Error occured while fetching the data from DB", e.getMessage());
			throw new WebServiceException("Error occured while fetching the data from DB");
		}
		logger.info("getAllApplicationServices method ends");
		return null;
	}

	@Override
	public Webservice getApplicationHostByAppName(String webserviceAppName) {
		logger.info("getApplicationHostByAppName method starts");
 		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			String sql = "FROM Webservice where applicationName = '"+webserviceAppName+"'";
			Query query = session.createQuery(sql);
			List<Webservice> results = query.list();
			if (null != results && !results.isEmpty()) {
 				return (Webservice) results.get(0);
 			}
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			logger.error("Error occured while fetching the data from DB", e.getMessage());
			throw new WebServiceException("Error occured while fetching the data from DB");
		}
		logger.info("getApplicationHostByAppName method ends");
		return null;
	}

	 

	}
