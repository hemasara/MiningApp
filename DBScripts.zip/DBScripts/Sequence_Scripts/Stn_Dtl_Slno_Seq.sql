--------------------------------------------------------
--  File created - Wednesday-December-21-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence STN_DTL_SLNO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."STN_DTL_SLNO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
