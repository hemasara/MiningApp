-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.54


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema miningdb
--

CREATE DATABASE IF NOT EXISTS miningdb;
USE miningdb;

--
-- Definition of table `tbl_organisation`
--

DROP TABLE IF EXISTS `tbl_organisation`;
CREATE TABLE `tbl_organisation` (
  `ORGANISATION_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ADDRESS` varchar(255) NOT NULL,
  `ORGANISATION_CONTACTEMAIL` varchar(255) NOT NULL,
  `CREATED_BY` varchar(255) NOT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `ORGANISATION_LOCATION` varchar(255) NOT NULL,
  `ORGANISATION_NAME` varchar(255) NOT NULL,
  `ORGANISATION_TYPE` varchar(255) NOT NULL,
  `ORGANISATION_CONTACTNO` varchar(255) NOT NULL,
  PRIMARY KEY (`ORGANISATION_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_organisation`
--

/*!40000 ALTER TABLE `tbl_organisation` DISABLE KEYS */;
INSERT INTO `tbl_organisation` (`ORGANISATION_ID`,`ADDRESS`,`ORGANISATION_CONTACTEMAIL`,`CREATED_BY`,`CREATED_DATE`,`ORGANISATION_LOCATION`,`ORGANISATION_NAME`,`ORGANISATION_TYPE`,`ORGANISATION_CONTACTNO`) VALUES 
 (1,'Solinganallur,Chennai','contact@techmahindra.com','Admin','2017-03-09 11:17:32','chennai','techm','IT Services','444444444'),
 (2,'Solinganallur,Chennai','contact@techmahindraChennai.com','Admin','2017-03-09 11:23:33','chennai TechM','techm Chennai','IT Services','444444444'),
 (3,'Perungudi,Chennai','contact@ford.com','Admin','2017-03-09 11:23:44','chennai Ford','Ford Chennai','Vehicle Manufacturing','444444444'),
 (4,'Karapakkam,Chennai','contact@scb.com','Admin','2017-03-09 11:23:54','chennai SCB','SCB','Banking Services','444444444'),
 (5,'chennai','contact@nissan.com','Admin','2017-03-09 18:56:10','chennai','nissan chennai','motor vehicle','434344343');
/*!40000 ALTER TABLE `tbl_organisation` ENABLE KEYS */;


--
-- Definition of table `tbl_status`
--

DROP TABLE IF EXISTS `tbl_status`;
CREATE TABLE `tbl_status` (
  `STATUS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `STATUS_NAME` varchar(255) NOT NULL,
  `STATUS_DESC` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`STATUS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_status`
--

/*!40000 ALTER TABLE `tbl_status` DISABLE KEYS */;
INSERT INTO `tbl_status` (`STATUS_ID`,`STATUS_NAME`,`STATUS_DESC`) VALUES 
 (1,'Active','Active User'),
 (2,'Pending','Pending details organisation and roles values'),
 (3,'InActive','Inactive User.. Please contact Admin');
/*!40000 ALTER TABLE `tbl_status` ENABLE KEYS */;


--
-- Definition of table `tbl_stone_details`
--

DROP TABLE IF EXISTS `tbl_stone_details`;
CREATE TABLE `tbl_stone_details` (
  `STONE_SLNO` int(11) NOT NULL AUTO_INCREMENT,
  `STONE_COLOUR` varchar(255) NOT NULL,
  `CREATED_BY` varchar(255) DEFAULT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `STONE_HEIGHT` double NOT NULL,
  `STONE_LENGTH` double NOT NULL,
  `STONE_QTY` int(11) NOT NULL,
  `STONE_TYPE` varchar(255) NOT NULL,
  `STONE_WIDTH` double NOT NULL,
  PRIMARY KEY (`STONE_SLNO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_stone_details`
--

/*!40000 ALTER TABLE `tbl_stone_details` DISABLE KEYS */;
INSERT INTO `tbl_stone_details` (`STONE_SLNO`,`STONE_COLOUR`,`CREATED_BY`,`CREATED_DATE`,`STONE_HEIGHT`,`STONE_LENGTH`,`STONE_QTY`,`STONE_TYPE`,`STONE_WIDTH`) VALUES 
 (1,'test',NULL,'2017-03-09 18:58:56',50,5,1,'test',100);
/*!40000 ALTER TABLE `tbl_stone_details` ENABLE KEYS */;


--
-- Definition of table `tbl_user_registration`
--

DROP TABLE IF EXISTS `tbl_user_registration`;
CREATE TABLE `tbl_user_registration` (
  `EMP_SRL_NUM` int(11) NOT NULL AUTO_INCREMENT,
  `CREATED_BY` varchar(255) DEFAULT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `USER_PASSWORD` varchar(255) NOT NULL,
  `MOBILE` varchar(255) NOT NULL,
  `USER_ROLE` varchar(255) NOT NULL,
  `USER_NAME` varchar(255) NOT NULL,
  `ORG_ID` int(11) DEFAULT NULL,
  `ROLES_ID` int(11) DEFAULT NULL,
  `STATUS_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMP_SRL_NUM`),
  KEY `FK_ktlk48hye7b4wiimtfecv0t2w` (`ORG_ID`),
  KEY `FK_sg7whkkatxf1ma9sjl8jbrcr3` (`ROLES_ID`),
  KEY `FK_hgh151uact3yx9i922deb6wov` (`STATUS_ID`),
  CONSTRAINT `FK_hgh151uact3yx9i922deb6wov` FOREIGN KEY (`STATUS_ID`) REFERENCES `tbl_status` (`STATUS_ID`),
  CONSTRAINT `FK_ktlk48hye7b4wiimtfecv0t2w` FOREIGN KEY (`ORG_ID`) REFERENCES `tbl_organisation` (`ORGANISATION_ID`),
  CONSTRAINT `FK_sg7whkkatxf1ma9sjl8jbrcr3` FOREIGN KEY (`ROLES_ID`) REFERENCES `tbl_user_roles` (`USER_ROLES_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_registration`
--

/*!40000 ALTER TABLE `tbl_user_registration` DISABLE KEYS */;
INSERT INTO `tbl_user_registration` (`EMP_SRL_NUM`,`CREATED_BY`,`CREATED_DATE`,`EMAIL`,`USER_PASSWORD`,`MOBILE`,`USER_ROLE`,`USER_NAME`,`ORG_ID`,`ROLES_ID`,`STATUS_ID`) VALUES 
 (1,'sekar','2017-03-09 11:01:56','sekar@123.com','sekar','2342344334','Admin','sekar',1,2,1),
 (2,'saravana','2017-03-09 12:08:43','saravana@123.com','saravana','34343434344','Admin','saravana',2,1,1);
/*!40000 ALTER TABLE `tbl_user_registration` ENABLE KEYS */;


--
-- Definition of table `tbl_user_roles`
--

DROP TABLE IF EXISTS `tbl_user_roles`;
CREATE TABLE `tbl_user_roles` (
  `USER_ROLES_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ROLE_DESC` varchar(255) DEFAULT NULL,
  `USER_ROLE_NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`USER_ROLES_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_roles`
--

/*!40000 ALTER TABLE `tbl_user_roles` DISABLE KEYS */;
INSERT INTO `tbl_user_roles` (`USER_ROLES_ID`,`USER_ROLE_DESC`,`USER_ROLE_NAME`) VALUES 
 (1,'User','User'),
 (2,'Admin','Admin');
/*!40000 ALTER TABLE `tbl_user_roles` ENABLE KEYS */;


--
-- Definition of table `tbl_work_order`
--

DROP TABLE IF EXISTS `tbl_work_order`;
CREATE TABLE `tbl_work_order` (
  `WRK_ODR_SLNO` int(11) NOT NULL AUTO_INCREMENT,
  `CREATED_BY` varchar(255) DEFAULT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `EMP_NAME` varchar(255) NOT NULL,
  `TIME_IN` varchar(255) NOT NULL,
  `TIME_OUT` varchar(255) NOT NULL,
  `WORKED_HRS` varchar(255) NOT NULL,
  PRIMARY KEY (`WRK_ODR_SLNO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_work_order`
--

/*!40000 ALTER TABLE `tbl_work_order` DISABLE KEYS */;
INSERT INTO `tbl_work_order` (`WRK_ODR_SLNO`,`CREATED_BY`,`CREATED_DATE`,`EMP_NAME`,`TIME_IN`,`TIME_OUT`,`WORKED_HRS`) VALUES 
 (1,'sekar','2017-03-09 19:01:38','sekar','21:34','20:35','23:01');
/*!40000 ALTER TABLE `tbl_work_order` ENABLE KEYS */;


--
-- Definition of table `test00`
--

DROP TABLE IF EXISTS `test00`;
CREATE TABLE `test00` (
  `testid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testvalues` int(10) unsigned NOT NULL,
  PRIMARY KEY (`testid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test00`
--

/*!40000 ALTER TABLE `test00` DISABLE KEYS */;
INSERT INTO `test00` (`testid`,`testvalues`) VALUES 
 (1,1000),
 (2,2002),
 (3,2000),
 (4,3003),
 (5,2004),
 (6,1002);
/*!40000 ALTER TABLE `test00` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
